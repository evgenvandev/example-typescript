# tscolorballs

Создана [по учебнику](https://urvanov.ru/2019/05/08/%d1%83%d1%87%d0%b5%d0%b1%d0%bd%d0%b8%d0%ba-typescript/).

В эту игру можно [играть прямо в браузере](https://urvanov.ru/projects/games/tscolorballs/).

