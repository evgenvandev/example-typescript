enum ProcessState {
    READY,
    PROCESSED
}