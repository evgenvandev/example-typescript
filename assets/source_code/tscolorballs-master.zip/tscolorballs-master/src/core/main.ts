// Created by https://urvanov.ru
(function () {
    document.addEventListener("DOMContentLoaded", function() {
        let engine:Engine = new Engine();
    });

    
})();