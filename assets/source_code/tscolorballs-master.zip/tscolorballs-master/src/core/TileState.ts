enum TileState {
    EMPTY,
    RED,
    GREEN,
    BLUE,
    YELLOW
}