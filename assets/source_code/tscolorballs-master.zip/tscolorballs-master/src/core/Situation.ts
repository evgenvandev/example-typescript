enum Situation {
    CLEAR_SCREEN,
    GAME,
    ANIMATION,
    SHOW_SCORE,
    END_GAME
}